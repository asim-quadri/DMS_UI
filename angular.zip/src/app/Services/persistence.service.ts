import { Injectable } from '@angular/core';
import { UsersModel } from '../Models/Users';
import { json } from '@rxweb/reactive-form-validators';
import { Router } from '@angular/router';
import { RolesModels } from '../Models/roles';
import { MenuOptionModel } from '../Models/Users';

@Injectable({
  providedIn: 'root',
})
export class PersistenceService {
  user: UsersModel = {};
  role: RolesModels = {};
  menuOptions: MenuOptionModel[] = [];

  constructor(private router: Router) {
    var userobje = sessionStorage.getItem('currentUser')!;
    if (userobje) {
      this.user = JSON.parse(userobje);
    }
  }

  // setLocalStorage(key: string, data: any): void {
  //   localStorage.setItem(key, JSON.stringify(data))
  // }

  // removelocalStorage(Key: string){
  //   localStorage.removeItem(Key);
  // }

  // getLocalStorage(key: string){

  // }

  setSessionStorage(key: string, data: any): void {
    sessionStorage.setItem(key, JSON.stringify(data));
  }

  removeSessionStorage(key: string) {
    sessionStorage.removeItem(key);
  }

  getSessionStorage(Key: string) {
    return JSON.parse(sessionStorage.getItem(Key) || '{}');
  }

  getByUserId(UserId: string) {
    return JSON.parse(sessionStorage.getItem(UserId) || '{}');
  }

  getOrganizationId() {
    return this.user.organizationId;
  }
  getUserUID() {
    return this.user!.uid ? this.user!.uid : null;
  }

  getRoleUID() {
    return this.role!.uid ? this.role!.uid : null;
  }

  getUserId() {
    return this.user.id;
  }

  getManagerId() {
    return this.user.managerId;
  }

  getUserName() {
    return this.user.fullName;
  }

  getRoleId() {
    return this.user.roleId;
  }

  /**
   * 'COMPSEQR360' (core Users table) or 'DMS' (DmsUser table) — which identity source
   * authenticated this login. Checked defensively against both casings since the API
   * spec documents this field as `LoginSource` (PascalCase) while the rest of the
   * login response this app already relies on is camelCase — until confirmed live,
   * this covers either.
   */
  getLoginSource(): string | undefined {
    const u: any = this.user;
    return u?.loginSource ?? u?.LoginSource;
  }

  isDmsUser() {
    const source = (this.getLoginSource() || '').toString().toUpperCase();
    return source === 'DMS';
  }

  /**
   * DMS access-control endpoints (tree/files/rename/delete) accept an optional
   * userType so they know whether the userId they were given is a core Users.Id
   * or a DmsUser.Id. For a DMS-sourced login, getUserId() actually holds the
   * DmsUser.Id, so those calls must pass userType=DmsUser.
   */
  getUserType(): 'User' | 'DmsUser' {
    return this.isDmsUser() ? 'DmsUser' : 'User';
  }

  getRole() {
    return this.user.roleName;
  }

  isUser() {
    return this.user.roleName == 'User' ? true : false;
  }

  set isSuperAdmin(value: boolean) {
    sessionStorage.setItem('isSuperAdmin', JSON.stringify(value));
  }

  get isSuperAdmin() {
    const res = sessionStorage.getItem('isSuperAdmin') as any;
    return Boolean(JSON.parse(res));
  }


  logout() {
    sessionStorage.clear();
    this.router.navigate(['/']).then(() => {
      window.location.reload();
    });
  }
}
